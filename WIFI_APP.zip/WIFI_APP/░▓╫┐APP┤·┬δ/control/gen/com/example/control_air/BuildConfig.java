/** Automatically generated file. DO NOT MODIFY */
package com.example.control_air;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}